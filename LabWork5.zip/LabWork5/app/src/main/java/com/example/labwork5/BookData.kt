package com.example.labwork5

import com.squareup.moshi.Json

//data class BookData(val author: String, val title: String, val published: String, val image: Int)

data class Data (
    val articles: List<BookData>
)

data class BookData (
//    @Json(name =  "author") val author: String,
//    @Json(name = "title") val title: String,
    var author: String?,
    var title: String?,
    @Json(name = "publishedAt") val published: String,
)