package com.example.labwork5

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.lang.Exception

class HostViewModel: ViewModel() {
    private val _response = MutableLiveData<String>()

    private var _listBooks = MutableLiveData<List<BookData>>()

    val output: LiveData<List<BookData>>
        get() = _listBooks

    val response: LiveData<String>
        get() = _response

    init {
        loadDataFromInternet()
    }


    private fun loadDataFromInternet() {
        viewModelScope.launch {
            try {
                val json = Api.retrofitService.getData()
                _listBooks.value = json.articles
                _response.value = "Success: ${_listBooks.value} data retrieved"
                Log.i("net-test", "loaded: " + response.value + _listBooks)
            } catch (e: Exception) {
                _response.value = "Failure: ${e.message}"
                Log.i("net-test", "not loaded: " + response.value)
            }
        }
    }
}