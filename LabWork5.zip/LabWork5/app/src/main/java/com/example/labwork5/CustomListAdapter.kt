package com.example.labwork5

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView


class CustomListAdapter : RecyclerView.Adapter<CustomListAdapter.ElemViewHolder>() {
    private var count = 0
    var data = listOf<BookData>()
        @SuppressLint("NotifyDataSetChanged")
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    companion object{
        val swapImages = arrayListOf(
            R.drawable.books1, R.drawable.books2,
            R.drawable.books3, R.drawable.books4,
            R.drawable.books5, R.drawable.books6,
            R.drawable.books7, R.drawable.books8,
            R.drawable.books9, R.drawable.books10,
            R.drawable.books11, R.drawable.books12,
            R.drawable.books13, R.drawable.books14)
    }


    class ElemViewHolder(itemView: View, private val index: Int): RecyclerView.ViewHolder(itemView) {
        private var titleViewRow: String = ""
        private val textViewRow: TextView = itemView.findViewById(R.id.contact_name)
        private val imageView: ImageView = itemView.findViewById(R.id.image)
        private val button: Button = itemView.findViewById(R.id.button)
        lateinit var published: String
        init {
            button.setOnClickListener { view ->
                Toast.makeText(view?.context, published, Toast.LENGTH_LONG).show()
            }

            button.setOnClickListener { view ->
                Toast.makeText(view.context, titleViewRow, Toast.LENGTH_LONG).show()
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$titleViewRow"))
                view.context.startActivity(intent)
            }
        }

        @SuppressLint("SetTextI18n")
        fun setData(autor: String, title: String, position: Int, published: String) {
            //textViewRow.text = "Position: $position, index: $index\nAuthor: $autor\n\tTitle: $title"


            titleViewRow = title
            textViewRow.text = "Author: $autor\nTitle: $title"
            imageView.setImageResource(swapImages[(0..12).random()])
            this.published = published
        }

        companion object {
            fun from(parent: ViewGroup, viewType: Int): ElemViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val view = layoutInflater.inflate(R.layout.list_item, parent, false)

                return ElemViewHolder(view, viewType)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ElemViewHolder {
        return ElemViewHolder.from(parent, count++)
    }

    override fun onBindViewHolder(holder: ElemViewHolder, position: Int) {
        val book = data[position]
        if (book.title == null) {
            book.title = "null"
        }
        if (book.author == null) {
            book.author = "null"
        }
        holder.setData(book.author!!, book.title!!, position, book.published)
    }

    override fun getItemCount(): Int {
        return data.size
    }
}