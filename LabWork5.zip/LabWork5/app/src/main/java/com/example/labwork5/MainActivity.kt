package com.example.labwork5

import android.content.res.AssetManager
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.labwork5.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    private var textUnsaved: String = "UNSAVED: "
    companion object {
        private var textSavedStatic: String = "SAVED_STATIC: "
    }
    private var textSavedBundle: String = "SAVED_BUNDLE: "

    private lateinit var recyclerView: RecyclerView
    private lateinit var viewAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager

    private fun AssetManager.readFile(fileName: String) = open(fileName)
        .bufferedReader()
        .use {
            it.readText()
        }

    private fun addText(text: String) {
        textUnsaved += text
        textSavedBundle += text
        textSavedStatic += text
        binding.apply {
            textNotSAVED.text = textUnsaved
            textSAVEDBUNDLE.text = textSavedBundle
            textSAVEDSTATIC.text = textSavedStatic
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        addText("_onCreate, ")

        var spanCount = 2
        if(resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE){
            spanCount = 3
        }
        val grid = StaggeredGridLayoutManager(spanCount, StaggeredGridLayoutManager.VERTICAL)

        viewManager = grid
        viewAdapter = CustomListAdapter()
        (viewAdapter as CustomListAdapter).data = emptyList()

        viewModel.output.observeForever {
                it -> (viewAdapter as CustomListAdapter).data = it
        }

        recyclerView = findViewById<RecyclerView>(R.id.recycler_view).apply {
            setHasFixedSize(true)
            layoutManager = viewManager
            adapter = viewAdapter
        }
    }

    override fun onStart() {
        super.onStart()
        addText("_onStart, ")
    }

    override fun onResume() {
        super.onResume()
        addText("_onResume, ")
    }

    override fun onPause() {
        super.onPause()
        addText("_onPause, ")
    }

    override fun onStop() {
        super.onStop()
        addText("_onStop, ")
    }

    override fun onDestroy() {
        super.onDestroy()
        addText("_onDestroy, ")
    }

    override fun onSaveInstanceState(savedInstanceState: Bundle) {
        addText("_onSaveInstanceState, ")
        savedInstanceState.putString("textSavedBundle", textSavedBundle)

        super.onSaveInstanceState(savedInstanceState)
    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)

        textSavedBundle = savedInstanceState.getString("textSavedBundle").toString()
        addText("_onRestoreInstanceState, ")
    }

    private val viewModel: HostViewModel by lazy {
        ViewModelProvider(this).get(HostViewModel::class.java)
    }
}