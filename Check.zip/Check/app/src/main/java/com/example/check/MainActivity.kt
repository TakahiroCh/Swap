package com.example.check

import android.content.ContentValues.TAG
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import com.example.check.databinding.ActivityMainBinding
import java.lang.Exception

class MainActivity : AppCompatActivity()  {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


//        findViewById<Button>(R.id.move_to_child).setOnClickListener {
//            Toast.makeText(it.context, "move", Toast.LENGTH_LONG).show()
//            val intent = Intent(this@MainActivity, ChildActivity::class.java)
//            startActivity(intent)
//        }

        val navController = this.findNavController(R.id.navigation_fragment)
        NavigationUI.setupActionBarWithNavController(this, navController)

        if (intent.hasExtra("news")) {
            Toast.makeText(this,  intent.getStringExtra("news"), Toast.LENGTH_LONG).show()
            findViewById<TextView>(R.id.news_fresh).text = intent.getStringExtra("news")
        } else {
            Toast.makeText(this,  "None", Toast.LENGTH_LONG).show()
            findViewById<TextView>(R.id.news_fresh).text = "None"
        }






    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = this.findNavController(R.id.navigation_fragment)
        return navController.navigateUp()
    }
}
