package com.example.check

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation

class SecondFragment: Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.second_fragment, container, false)

        view.findViewById<Button>(R.id.button_add_spam).setOnClickListener(object : View.OnClickListener {
            override fun onClick(p0: View?) {
                Toast.makeText(p0?.context, view.findViewById<TextView>(R.id.spam).text, Toast.LENGTH_LONG).show()
                view.findViewById<TextView>(R.id.spam).text = getString(R.string.yandere_word).repeat(1200)
            }
        })
        return view
    }
}