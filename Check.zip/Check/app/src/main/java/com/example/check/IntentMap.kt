package com.example.check

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import android.content.pm.PackageManager
import android.provider.ContactsContract
import android.widget.EditText
import androidx.core.app.ShareCompat
import java.net.URLEncoder


class IntentMap:  Fragment() {
    val REQUEST_SELECT_PHONE_NUMBER = 1

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.intent_fragment, container, false)

        view.findViewById<Button>(R.id.search_google).setOnClickListener { p0 ->
            Toast.makeText(p0?.context, view.findViewById<EditText>(R.id.search_bar).text.toString(), Toast.LENGTH_LONG).show()
            val search = view.findViewById<EditText>(R.id.search_bar).text.toString()
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$search"))
            startActivity(intent)
        }

        view.findViewById<Button>(R.id.button_open_map).setOnClickListener { p0 ->
            val gmmIntentUri = Uri.parse("geo:55.7558,37.6173?z=10")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
            mapIntent.setPackage("com.google.android.apps.maps")
            startActivity(mapIntent)
        }

        view.findViewById<Button>(R.id.button_number).setOnClickListener { p0 ->
            val phoneNumber = view.findViewById<EditText>(R.id.number).text.toString()
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
            }
            startActivity(intent)
        }


        return view
    }

}