package com.example.check

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ShareCompat
import androidx.core.widget.addTextChangedListener

class ChildActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_child)

        findViewById<Button>(R.id.button_share_info).setOnClickListener { p0 ->
            val mimeType = "text/plain"
            val title = "shareingstring"
            var text = findViewById<EditText>(R.id.share_info).text.toString()
            if (intent.hasExtra("random")) {
                text +=  " " + intent.getStringExtra("random")
            }

            ShareCompat.IntentBuilder.from(this@ChildActivity)
                .setChooserTitle(title)
                .setType(mimeType)
                .setText(text)
                .startChooser()
        }

        val news = findViewById<EditText>(R.id.news)
        findViewById<Button>(R.id.button_news).setOnClickListener {
            val intent = Intent(this@ChildActivity, MainActivity::class.java)
            intent.putExtra("news", news.text.toString())
            startActivity(intent)
        }


    }
}