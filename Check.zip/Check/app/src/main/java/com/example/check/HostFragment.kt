package com.example.check

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation

class HostFragment: Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_host, container, false)
        view.findViewById<Button>(R.id.button_laboratory_work_1).setOnClickListener(
            Navigation.createNavigateOnClickListener(R.id.action_host_fragment_to_second_fragment)
        )
        view.findViewById<Button>(R.id.button_intent_map).setOnClickListener(
            Navigation.createNavigateOnClickListener(R.id.action_host_fragment_to_intent_fragment)
        )

        view.findViewById<Button>(R.id.move_to_child).setOnClickListener {
            Toast.makeText(it.context, "move", Toast.LENGTH_LONG).show()
            val intent = Intent(it.context, ChildActivity::class.java)
            startActivity(intent)
        }

        view.findViewById<Button>(R.id.random).setOnClickListener {
            val intent = Intent(it.context, ChildActivity::class.java)
            val allowedChars = ('A'..'Z') + ('a'..'z') + ('0'..'9')
            val randomStr = (1..21).map { allowedChars.random() }.joinToString("")
            intent.putExtra("random", randomStr)
            Toast.makeText(it.context, randomStr, Toast.LENGTH_LONG).show()
            startActivity(intent)
        }

        return view
    }
}